<?php

if (!defined('IN_IA')) {
	exit('Access Denied');
}

class Empty_EweiShopV2Page extends MobilePage
{
	public function main()
	{
	}
}

?>
